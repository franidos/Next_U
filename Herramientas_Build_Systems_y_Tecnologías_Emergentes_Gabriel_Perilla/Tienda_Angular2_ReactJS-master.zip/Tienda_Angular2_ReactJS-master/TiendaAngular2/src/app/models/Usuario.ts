
export class Usuario {
  id: number;
  email: string;
  password: string;
}
