*Using React 15.4.0, React Router 4, and Firebase 3.6.1*
*Angel Rosendo Condori Coaquira
#### Instructions:
* Swap out the firebase config in ```config/constants``` with your own
* ```npm install```
* ```npm start```
* Visit ```localhost:3000```
