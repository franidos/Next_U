import React, { Component } from 'react'

export default class Home extends Component {
  render () {
    return (
      <div>
        Home. Not Protected. Anyone can see this.
      </div>
    )
  }
}